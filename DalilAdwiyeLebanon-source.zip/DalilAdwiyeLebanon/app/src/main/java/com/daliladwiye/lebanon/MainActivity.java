package com.daliladwiye.lebanon;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.content.Context;
import android.util.Log;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.*;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.json.*;

public class MainActivity extends Activity {
    private WebView web;
    private ConnectivityManager.NetworkCallback networkCallback;
    private static final String MOH_PAGE = "https://www.moph.gov.lb/en/Drugs/index/3/14046/letter:N/page:3/sort:Drug.brand_name/direction:DESC";
    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (new Bridge().hasInternet()) new Bridge().syncNow();
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "NativeApp");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        watchNetwork();
    }
    private void watchNetwork() {
        ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        if(cm==null)return;
        networkCallback=new ConnectivityManager.NetworkCallback(){
            @Override public void onAvailable(android.net.Network network){
                runOnUiThread(() -> { if(web!=null) web.evaluateJavascript("if(window.NativeApp){NativeApp.syncNow();}",null); });
            }
        };
        try { cm.registerDefaultNetworkCallback(networkCallback); } catch(Exception e){ Log.w("MOPH_SYNC","network callback unavailable",e); }
    }
    @Override protected void onDestroy(){
        try { ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE); if(cm!=null&&networkCallback!=null)cm.unregisterNetworkCallback(networkCallback); }catch(Exception ignored){}
        super.onDestroy();
    }
    public class Bridge {
        @JavascriptInterface public boolean hasInternet() {
            ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            if(cm==null||cm.getActiveNetwork()==null)return false;
            NetworkCapabilities nc=cm.getNetworkCapabilities(cm.getActiveNetwork());
            return nc!=null&&nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        }
        @JavascriptInterface public void syncNow() {
            new Thread(() -> {
                try {
                    JSONArray rows = downloadAndParse();
                    String js="window.onNativeSyncSuccess("+JSONObject.quote(rows.toString())+","+JSONObject.quote(new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()))+")";
                    runOnUiThread(() -> web.evaluateJavascript(js,null));
                } catch(Exception e) {
                    Log.e("MOPH_SYNC", "sync failed", e);
                    String msg=e.getMessage()==null?"Update failed":e.getMessage();
                    String js="window.onNativeSyncError("+JSONObject.quote(msg)+")";
                    runOnUiThread(() -> web.evaluateJavascript(js,null));
                }
            }).start();
        }
    }
    private JSONArray downloadAndParse() throws Exception {
        String html=getText(MOH_PAGE);
        Matcher m=Pattern.compile("href=[\\\"']([^\\\"']*WebMarketed[^\\\"']*\\.xls)[\\\"']",Pattern.CASE_INSENSITIVE).matcher(html);
        String file=null; while(m.find()) file=m.group(1);
        if(file==null) throw new IOException("لم أجد ملف Excel حديثاً على صفحة الوزارة");
        URL fileUrl=new URL(new URL(MOH_PAGE),file);
        File tmp=new File(getCacheDir(),"moph-latest.xls");
        HttpURLConnection c=(HttpURLConnection)fileUrl.openConnection(); c.setConnectTimeout(20000); c.setReadTimeout(40000); c.setInstanceFollowRedirects(true);
        try(InputStream in=c.getInputStream();FileOutputStream out=new FileOutputStream(tmp)){byte[]buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);}
        JSONArray result=new JSONArray();
        try(InputStream in=new FileInputStream(tmp); HSSFWorkbook book=new HSSFWorkbook(in)) {
            Sheet sheet=book.getSheetAt(0); int header=-1; int colAtc=-1,colName=-1,colIngredients=-1,colDosage=-1,colForm=-1,colPrice=-1;
            for(int r=sheet.getFirstRowNum();r<=Math.min(sheet.getLastRowNum(),30);r++){
                Row row=sheet.getRow(r); if(row==null)continue;
                for(Cell cell:row){String v=cellText(cell).toLowerCase(); if(v.contains("name")||v.contains("brand")){header=r;break;}}
                if(header>=0){for(Cell cell:row){String v=cellText(cell).toLowerCase();int ci=cell.getColumnIndex();if(v.contains("atc"))colAtc=ci;if(v.contains("name")||v.contains("brand"))colName=ci;if(v.contains("ingredient"))colIngredients=ci;if(v.contains("dosage")||v.equals("strength"))colDosage=ci;if(v.contains("form"))colForm=ci;if(v.contains("price"))colPrice=ci;}break;}
            }
            if(header<0||colName<0)throw new IOException("لم أتعرف على أعمدة ملف الوزارة؛ لم يتم استبدال قاعدة البيانات القديمة");
            for(int r=header+1;r<=sheet.getLastRowNum();r++){
                Row row=sheet.getRow(r);if(row==null)continue;String name=getCell(row,colName);if(name.isEmpty())continue;
                JSONObject o=new JSONObject();o.put("name",name);o.put("atc",getCell(row,colAtc));o.put("ingredients",getCell(row,colIngredients));o.put("dosage",getCell(row,colDosage));o.put("form",getCell(row,colForm));o.put("price",getCell(row,colPrice));o.put("source","MOPH");
                result.put(o);
            }
        }
        if(result.length()==0)throw new IOException("ملف الوزارة لم يتضمن سجلات قابلة للقراءة");
        return result;
    }
    private String getText(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(20000);c.setReadTimeout(30000);c.setRequestProperty("User-Agent","DalilAdwiyeLebanon/1.0");try(InputStream in=c.getInputStream();ByteArrayOutputStream b=new ByteArrayOutputStream()){byte[]x=new byte[8192];int n;while((n=in.read(x))!=-1)b.write(x,0,n);return b.toString("UTF-8");}}
    private String getCell(Row r,int i){return i<0?"":cellText(r.getCell(i));}
    private static String cellText(Cell c){if(c==null)return "";try{c.setCellType(CellType.STRING);return c.getStringCellValue().trim();}catch(Exception e){return c.toString().trim();}}
}

const $=id=>document.getElementById(id);
let lang=localStorage.getItem('lang')||'ar';
let drugs=JSON.parse(localStorage.getItem('drugs')||'[]');
let randomOrder=[];
const classes=[['A','الهضم والاستقلاب','Alimentary tract & metabolism'],['B','الدم وأعضاء تكوين الدم','Blood & blood forming organs'],['C','القلب والأوعية','Cardiovascular system'],['D','الجلد','Dermatologicals'],['G','الجهاز البولي والتناسلي والهرمونات الجنسية','Genito-urinary system & sex hormones'],['H','الهرمونات الجهازية','Systemic hormonal preparations'],['J','مضادات العدوى الجهازية','Systemic anti-infectives'],['L','مضادات الأورام والمناعة','Antineoplastic & immunomodulating agents'],['M','الجهاز العضلي الهيكلي','Musculo-skeletal system'],['N','الجهاز العصبي','Nervous system'],['P','مضادات الطفيليات','Antiparasitic products'],['R','الجهاز التنفسي','Respiratory system'],['S','أدوية العين والأذن','Sensory organs'],['V','أدوية متنوعة','Various']];
function cls(atc){let c=(atc||'').charAt(0).toUpperCase();return classes.find(x=>x[0]===c)||['?','غير مصنف','Unclassified']}
function t(ar,en){return lang==='ar'?ar:en}
function toast(s){$('toast').textContent=s;$('toast').style.display='block';setTimeout(()=>$('toast').style.display='none',3500)}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function shuffle(items){let a=items.slice();for(let i=a.length-1;i>0;i--){let j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function categoryMatches(d,cat){return !cat||(d.atc||'').toUpperCase().startsWith(cat)}
function nameMatches(d,q){if(!q)return true;let needle=q.toLocaleLowerCase();return [d.name,d.ingredients,d.atc].some(v=>String(v||'').toLocaleLowerCase().includes(needle))}
function populateNames(){let names=[...new Set(drugs.map(d=>d.name).filter(Boolean))].sort((a,b)=>a.localeCompare(b));let selected=$('medicine').value;$('medicine').innerHTML=`<option value="">${t('كل الأدوية','All medicines')}</option>`+names.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('');$('medicine').value=names.includes(selected)?selected:''}
function populateClasses(){let selected=$('category').value;let seen=new Set(drugs.map(d=>(d.atc||'').charAt(0).toUpperCase()).filter(Boolean));$('category').innerHTML=`<option value="">${t('كل التصنيفات','All classes')}</option>`+classes.filter(c=>seen.has(c[0])).map(c=>`<option value="${c[0]}">${lang==='ar'?c[1]:c[2]}</option>`).join('');$('category').value=seen.has(selected)?selected:''}
function getFiltered(){let q=$('q').value.trim(),medicine=$('medicine').value,cat=$('category').value,ind=$('indication').value;return drugs.filter(d=>categoryMatches(d,cat)&&(!medicine||d.name===medicine)&&nameMatches(d,q)&&(!ind||((d.indications||[]).includes(ind))))}
function renderSuggestions(){let q=$('q').value.trim();let cat=$('category').value;let box=$('suggestions');if(!box)return;if(!q){box.hidden=true;box.innerHTML='';return}
  // Suggestions are drawn only from the currently selected category, if any.
  let matches=drugs.filter(d=>categoryMatches(d,cat)).flatMap(d=>[d.name,d.ingredients]).filter(Boolean);
  let unique=[...new Set(matches)].filter(v=>v.toLocaleLowerCase().includes(q.toLocaleLowerCase())).sort((a,b)=>a.localeCompare(b)).slice(0,8);
  box.innerHTML=unique.map(v=>`<button type="button" class="suggestion" data-value="${esc(v)}">${esc(v)}</button>`).join('');box.hidden=unique.length===0;
}
function render(){populateNames();populateClasses();let found=getFiltered();let hasAnyFilter=!!($('q').value.trim()||$('medicine').value||$('category').value||$('indication').value);let shown=hasAnyFilter?found:randomOrder.slice(0,50);
  $('count').textContent=found.length.toLocaleString();
  $('status').textContent=drugs.length?t('محفوظة على الجهاز · تعمل دون إنترنت','Saved on device · works offline'):t('قاعدة البيانات لم تُحمّل بعد','Database not loaded yet');
  $('results').innerHTML=shown.slice(0,150).map(d=>{let c=cls(d.atc);return `<article class="drug"><h3>${esc(d.name)}</h3><p>${t('المادة الفعالة','Ingredients')}: ${esc(d.ingredients||'—')}</p><p>${t('التركيز','Strength')}: ${esc(d.dosage||'—')} · ${t('الشكل','Form')}: ${esc(d.form||'—')}</p><p>${t('رمز ATC','ATC code')}: ${esc(d.atc||'—')} · ${t('السعر الرسمي','Official price')}: ${esc(d.price||'—')}</p><span class="tag">${lang==='ar'?c[1]:c[2]}</span><p>${t('دواعي الاستعمال: غير متوفرة في ملف التسجيل/السعر الرسمي.','Indications: not included in the official registration/price file.')}</p></article>`}).join('')||`<div class="empty">${drugs.length?t('لا توجد نتائج مطابقة.','No matching results.'):t('لم يتم تحميل قاعدة الأدوية بعد. عند توفر ملف Excel الرسمي من الوزارة، استخدم زر التحديث أو استورد ملفاً بصيغة CSV.','No medicines database has been loaded yet. When the official Ministry file is available, use Update or import a CSV file.')}</div>`;
  renderSuggestions();
}
$('q').addEventListener('input',render);
$('medicine').addEventListener('change',()=>{if($('medicine').value)$('q').value='';render()});
$('category').addEventListener('change',render);
$('indication').addEventListener('change',render);
$('suggestions').addEventListener('click',e=>{let b=e.target.closest('button[data-value]');if(!b)return;$('q').value=b.dataset.value;$('medicine').value='';$('suggestions').hidden=true;render();$('q').focus()});
document.addEventListener('click',e=>{if(!e.target.closest('.search-wrap'))$('suggestions').hidden=true});
$('langBtn').onclick=()=>{lang=lang==='ar'?'en':'ar';localStorage.setItem('lang',lang);setLang()};
$('syncBtn').onclick=()=>{if(window.NativeApp&&NativeApp.hasInternet()){toast(t('جارٍ جلب آخر ملف من موقع الوزارة…','Fetching the latest Ministry file…'));NativeApp.syncNow()}else toast(t('لا يوجد اتصال بالإنترنت. ستبقى النسخة المحفوظة متاحة.','No internet connection. Your saved offline copy remains available.'))};
window.onNativeSyncSuccess=(json,date)=>{try{let arr=JSON.parse(json);if(!Array.isArray(arr)||!arr.length)throw Error('empty');drugs=arr;randomOrder=shuffle(drugs);localStorage.setItem('drugs',JSON.stringify(drugs));localStorage.setItem('updated',date);$('updated').textContent=t('آخر تحديث: ','Last update: ')+date;render();toast(t('تم تحديث قاعدة البيانات بنجاح: ','Database updated: ')+arr.length)}catch(e){toast(t('لم يتم اعتماد الملف الجديد. بقيت النسخة السابقة محفوظة.','New file was not accepted. Previous database kept.'))}};
window.onNativeSyncError=msg=>toast(t('تعذّر التحديث: ','Update failed: ')+msg);
if(localStorage.getItem('updated'))$('updated').textContent=t('آخر تحديث: ','Last update: ')+localStorage.getItem('updated');
randomOrder=shuffle(drugs);
function setLang(){document.documentElement.lang=lang;document.documentElement.dir=lang==='ar'?'rtl':'ltr';document.querySelectorAll('[data-ar]').forEach(e=>e.textContent=e.dataset[lang]);$('langBtn').textContent=lang==='ar'?'EN':'عربي';$('appTitle').textContent=t('دليل أدوية لبنان','Lebanon Medicines Guide');render()}
setLang();
